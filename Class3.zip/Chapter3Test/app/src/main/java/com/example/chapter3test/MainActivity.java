package com.example.chapter3test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SeekBar;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tab = findViewById(R.id.tabLayout);
        tab.addTab(tab.newTab().setText("动画1"));
        tab.addTab(tab.newTab().setText("SeekBar动画"));
        tab.addTab(tab.newTab().setText("啥也没有"));

        final FragmentManager fmanager = getSupportFragmentManager();

        FragmentTransaction ftransac = fmanager.beginTransaction();
        ftransac.replace(R.id.fragment_container, new Fragment1());
        ftransac.commit();

        tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if(tab.getPosition() == 0)
                {
                    FragmentTransaction ftransac = fmanager.beginTransaction();
                    ftransac.replace(R.id.fragment_container, new Fragment1());
                    ftransac.commit();
                }
                if(tab.getPosition() == 1)
                {
                    FragmentTransaction ftransac = fmanager.beginTransaction();
                    ftransac.replace(R.id.fragment_container, new Fragment2());
                    ftransac.commit();
                }
                if(tab.getPosition() == 2)
                {
                    FragmentTransaction ftransac = fmanager.beginTransaction();
                    ftransac.replace(R.id.fragment_container, new Fragment3());
                    ftransac.commit();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
    });



    }


}
