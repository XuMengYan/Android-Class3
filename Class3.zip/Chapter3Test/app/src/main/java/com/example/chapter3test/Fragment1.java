package com.example.chapter3test;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.chapter3test.R;

public class Fragment1 extends Fragment {

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View fview = inflater.inflate(R.layout.layout_fragment1, container, false);
        ImageView image1 = fview.findViewById(R.id.imageKirov);

        Animator anim = AnimatorInflater.loadAnimator(getActivity(), R.animator.animator1);
        anim.setTarget(image1);
        anim.start();
        return fview;
    }

}
